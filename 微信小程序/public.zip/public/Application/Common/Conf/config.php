<?php
return array(
	//'配置项'=>'配置值'
	'URL_MODEL'	=>1,				
	'DB_TYPE'	=>'mysql',
	'DB_HOST'	=>'127.0.0.1',
	'DB_NAME'	=>'shop',
//	'DB_USER'	=>'longhai',
//	'DB_PWD'	=>'hlhjlonghai',
	'DB_USER'	=>'root',
	'DB_PWD'	=>'root',
	'DB_PORT'	=>3306,
	'DB_PREFIX' => 'shop_',
	
	// 'appid'=>'wxf15f32c67dd4301e',
	// 'appsec'=>'35d8b2da036cbe8b17d5869b13ae000b'
);