<?php
namespace Admin\Controller;
class MainController extends BaseController {
	
	public function index(){
		$this->display();
	}
	
	public function top(){
		$this->display();
	}
	
	public function left(){
		$this->display();
	}
	
	public function right(){
		$this->display();
	}
	
}