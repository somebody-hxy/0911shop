<?php
return array(
	//设置环境变量
	'TMPL_PARSE_STRING'=>array(
		'__images__'=>'/Public/admin/images'
	),
	
	//设置提示页
	'TMPL_ACTION_SUCCESS'=>'Public:success',
	'TMPL_ACTION_ERROR'=>'Public:error',
);